import GameCanvas from './engine/GameCanvas';
import HUD from './ui/HUD';

export default function App() {
  return (
    <div className="eaoin-app">
      <GameCanvas seed="eaoin_seed_2026" onExit={() => {}} />
      <HUD />
    </div>
  );
}
